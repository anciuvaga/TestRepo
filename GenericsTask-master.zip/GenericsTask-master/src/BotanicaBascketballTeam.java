public class BotanicaBascketballTeam extends  BascketBall {
    public BotanicaBascketballTeam(String name){super(name);}
}
