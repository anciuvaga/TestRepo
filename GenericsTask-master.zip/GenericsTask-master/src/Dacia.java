public class Dacia extends Football {
    public Dacia(String name){super(name);}
}
