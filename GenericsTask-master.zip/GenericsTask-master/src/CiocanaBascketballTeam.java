public class CiocanaBascketballTeam extends BascketBall {
    public CiocanaBascketballTeam(String name){super(name);}
}
