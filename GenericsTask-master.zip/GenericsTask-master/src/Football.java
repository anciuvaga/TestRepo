public class Football extends Sport {
    public Football(String name){super(name);}
}
