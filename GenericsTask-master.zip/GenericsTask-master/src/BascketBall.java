public class BascketBall extends  Sport {
    public BascketBall(String name){super(name);}
}
