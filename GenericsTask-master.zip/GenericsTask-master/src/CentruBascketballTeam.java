public class CentruBascketballTeam extends BascketBall {
    public CentruBascketballTeam (String name){super(name);}
}
