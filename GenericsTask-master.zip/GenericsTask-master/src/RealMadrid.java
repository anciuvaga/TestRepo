public class RealMadrid extends Football {
     public RealMadrid (String name){super(name);}
}
