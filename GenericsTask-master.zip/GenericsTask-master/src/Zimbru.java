public class Zimbru extends Football {
    public Zimbru(String name){super(name);}
}
