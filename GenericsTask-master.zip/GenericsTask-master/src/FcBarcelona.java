public class FcBarcelona extends Football {
    public FcBarcelona (String name){super(name);}
}
