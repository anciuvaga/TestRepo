public class Sport {
    public String name;
    public Sport(String name){
        this.name=name;
    }
    public String getName(){
        return  name;
    }

}
