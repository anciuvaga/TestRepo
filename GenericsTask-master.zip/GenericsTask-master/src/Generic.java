public class Generic {
}
