public class RiscaniBscketballTeam extends  BascketBall{
    public RiscaniBscketballTeam(String name){super(name);}
}
